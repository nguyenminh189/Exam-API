﻿using Microsoft.EntityFrameworkCore;

namespace Exam.Entities
{
    public class ApiContext : DbContext
    {
        public DbSet<Department> Departments { get; set; }
        public DbSet<Employee> Employees { get; set; }

        public ApiContext(DbContextOptions<ApiContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Department>(entity =>
            {
                entity.ToTable("Department_Tbl");
                entity.HasKey(d => d.DepartmentId);
                entity.Property(d => d.DepartmentName).IsRequired().HasMaxLength(100);
                entity.Property(d => d.DepartmentCode).IsRequired().HasMaxLength(10);
                entity.Property(d => d.Location).HasMaxLength(100);
                entity.Property(d => d.NumberOfEmployees).IsRequired();
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.ToTable("Employee_Tbl");
                entity.HasKey(e => e.EmployeeId);
                entity.Property(e => e.EmployeeName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.EmployeeCode).IsRequired().HasMaxLength(10);
                entity.Property(e => e.Rank).HasMaxLength(50);

                entity.HasOne(e => e.Department)
                      .WithMany(d => d.Employees)
                      .HasForeignKey(e => e.DepartmentId);
            });
        }
    }
}
