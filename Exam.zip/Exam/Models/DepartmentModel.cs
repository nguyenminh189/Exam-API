﻿using Exam.Entities;
using System.ComponentModel.DataAnnotations;

namespace Exam.Models
{
    public class DepartmentModel
    {
        public int DepartmentId { get; set; } // Primary Key

        [Required]
        [MaxLength(100)]
        public string DepartmentName { get; set; }

        [Required]
        [MaxLength(10)]
        public string DepartmentCode { get; set; }

        [MaxLength(100)]
        public string Location { get; set; }

        public int NumberOfEmployees { get; set; }

        public ICollection<Employee> Employees { get; set; }
    }

}
