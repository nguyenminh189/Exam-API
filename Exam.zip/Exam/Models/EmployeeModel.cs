﻿using Exam.Entities;
using System.ComponentModel.DataAnnotations;

namespace Exam.Models
{
    public class EmployeeModel
    {
        public int EmployeeId { get; set; }

        [Required]
        [MaxLength(100)]
        public string EmployeeName { get; set; }

        [Required]
        [MaxLength(10)]
        public string EmployeeCode { get; set; }

        [MaxLength(50)]
        public string Rank { get; set; }

        public int DepartmentId { get; set; }

        public Department Department { get; set; }
    }

}
